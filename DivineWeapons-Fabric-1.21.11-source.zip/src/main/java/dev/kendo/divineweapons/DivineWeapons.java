package dev.kendo.divineweapons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class DivineWeapons implements ModInitializer {
    public static final String MOD_ID = "divineweapons";

    public static final Block VOID_ALTAR = registerBlock("void_altar",
            new Block(AbstractBlock.Settings.copy(Blocks.OBSIDIAN).strength(8.0f, 1200.0f)));
    public static final Block STORM_ALTAR = registerBlock("storm_altar",
            new Block(AbstractBlock.Settings.copy(Blocks.CRYING_OBSIDIAN).strength(8.0f, 1200.0f)));
    public static final Block SOUL_ALTAR = registerBlock("soul_altar",
            new Block(AbstractBlock.Settings.copy(Blocks.POLISHED_BLACKSTONE_BRICKS).strength(8.0f, 1200.0f)));

    public static final Item VOIDBREAKER = registerItem("voidbreaker", new Item(new Item.Settings().maxCount(1)));
    public static final Item STORMPIERCER = registerItem("stormpiercer", new Item(new Item.Settings().maxCount(1)));
    public static final Item SOULREAPER = registerItem("soulreaper", new Item(new Item.Settings().maxCount(1)));

    private static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    private static Block registerBlock(String name, Block block) {
        Registry.register(Registries.BLOCK, id(name), block);
        Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
        return block;
    }

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, id(name), item);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(VOIDBREAKER);
            entries.add(STORMPIERCER);
            entries.add(SOULREAPER);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(VOID_ALTAR.asItem());
            entries.add(STORM_ALTAR.asItem());
            entries.add(SOUL_ALTAR.asItem());
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || world.isClient) return ActionResult.PASS;
            Block clicked = world.getBlockState(hit.getBlockPos()).getBlock();
            ItemStack held = player.getStackInHand(hand);

            if (clicked == VOID_ALTAR && held.isOf(Items.NETHER_STAR)) {
                if (!player.isCreative()) held.decrement(1);
                player.giveItemStack(new ItemStack(VOIDBREAKER));
                world.playSound(null, hit.getBlockPos(), SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE,
                        SoundCategory.BLOCKS, 1.5f, 0.65f);
                player.sendMessage(Text.literal("The Void Altar has forged the Voidbreaker."), true);
                return ActionResult.SUCCESS;
            }
            if (clicked == STORM_ALTAR && held.isOf(Items.TRIDENT)) {
                if (!player.isCreative()) held.decrement(1);
                player.giveItemStack(new ItemStack(STORMPIERCER));
                world.playSound(null, hit.getBlockPos(), SoundEvents.ITEM_TRIDENT_THUNDER,
                        SoundCategory.BLOCKS, 1.5f, 0.8f);
                player.sendMessage(Text.literal("The Storm Altar has forged the Stormpiercer."), true);
                return ActionResult.SUCCESS;
            }
            if (clicked == SOUL_ALTAR && held.isOf(Items.NETHERITE_SWORD)) {
                if (!player.isCreative()) held.decrement(1);
                player.giveItemStack(new ItemStack(SOULREAPER));
                world.playSound(null, hit.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN,
                        SoundCategory.BLOCKS, 1.0f, 0.7f);
                player.sendMessage(Text.literal("The Soul Altar has forged the Soulreaper."), true);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || hand != Hand.MAIN_HAND) return ActionResult.PASS;

            if (stack.isOf(VOIDBREAKER)) {
                if (player.getItemCooldownManager().isCoolingDown(stack.getItem())) return ActionResult.FAIL;
                player.getItemCooldownManager().set(stack.getItem(), 70);
                areaPulse(world, player, 6.0, 12.0f, ParticleTypes.PORTAL, 1.5f);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                        SoundCategory.PLAYERS, 1.5f, 0.55f);
                return ActionResult.SUCCESS;
            }
            if (stack.isOf(STORMPIERCER)) {
                if (player.getItemCooldownManager().isCoolingDown(stack.getItem())) return ActionResult.FAIL;
                player.getItemCooldownManager().set(stack.getItem(), 55);
                Vec3d look = player.getRotationVector();
                player.addVelocity(look.x * 1.8, Math.max(0.35, look.y * 1.4), look.z * 1.8);
                player.velocityModified = true;
                areaPulse(world, player, 3.5, 9.0f, ParticleTypes.ELECTRIC_SPARK, 0.8f);
                world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_TRIDENT_RIPTIDE_3,
                        SoundCategory.PLAYERS, 1.5f, 1.1f);
                return ActionResult.SUCCESS;
            }
            if (stack.isOf(SOULREAPER)) {
                if (player.getItemCooldownManager().isCoolingDown(stack.getItem())) return ActionResult.FAIL;
                player.getItemCooldownManager().set(stack.getItem(), 90);
                areaPulse(world, player, 5.0, 10.0f, ParticleTypes.SOUL, 1.0f);
                if (player instanceof LivingEntity living) {
                    living.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 160, 1));
                    living.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 160, 1));
                }
                world.playSound(null, player.getBlockPos(), SoundEvents.PARTICLE_SOUL_ESCAPE,
                        SoundCategory.PLAYERS, 1.5f, 0.8f);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    private static void areaPulse(World world, net.minecraft.entity.player.Player player,
                                  double radius, float damage, net.minecraft.particle.ParticleEffect particle,
                                  float particleScale) {
        Box box = player.getBoundingBox().expand(radius);
        for (Entity entity : world.getOtherEntities(player, box)) {
            if (entity instanceof LivingEntity target && target.isAlive()) {
                target.damage(world.getDamageSources().playerAttack(player), damage);
                Vec3d away = target.getPos().subtract(player.getPos()).normalize().multiply(0.9);
                target.addVelocity(away.x, 0.35, away.z);
                target.velocityModified = true;
            }
        }
        for (int i = 0; i < 45; i++) {
            double angle = (Math.PI * 2.0 * i) / 45.0;
            double x = player.getX() + Math.cos(angle) * radius * 0.75;
            double z = player.getZ() + Math.sin(angle) * radius * 0.75;
            world.spawnParticles(particle, x, player.getY() + 0.7, z, 2, 0.15, 0.25, 0.15, particleScale);
        }
    }
}
